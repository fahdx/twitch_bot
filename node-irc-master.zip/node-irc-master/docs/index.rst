Welcome to node-irc's documentation!
====================================

.. include:: ../README.rst

More detailed docs:
-------------------

.. toctree::
   :maxdepth: 2

   API

